package com.springplanner.travel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
