package com.springplanner.travel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;

import com.springplanner.travel.entity.User;
import com.springplanner.travel.model.SignUpForm;
import com.springplanner.travel.repository.UserRepository;

@Controller
public class SignUpController {

    // autowire user repository
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // method to get signup page
    @GetMapping(path = "/signup")
    public String getSignupPage() {
        return "signup";
    }
    // method to submit signup

    @PostMapping(path = "/signup")
    public String submitSignup(SignUpForm signupForm, Model model) {
        // Check for existing user with the same email or username
        boolean emailExists = userRepo.findByEmailId(signupForm.getEmailId()) != null;
        boolean usernameExists = userRepo.findByUsername(signupForm.getUsername()) != null;

        if (emailExists || usernameExists) {
            // Add an attribute to the model indicating a duplicate account exists
            model.addAttribute("signupError", "An account already exists for the given email or username.");
            return "signup"; // Return back to the signup page to display the error
        }

        // Create a new User object if no duplicates are found
        if (signupForm != null) {
            User user = new User(signupForm.getUsername(), signupForm.getFirstName(),
                    signupForm.getLastName(), signupForm.getEmailId(),
                    passwordEncoder.encode(signupForm.getPassword()));
            user.setEnabled(true);
            userRepo.save(user);
            return "signup-success";
        } else {
            // Handle the case where signupForm is null if necessary
            model.addAttribute("signupError", "The form data is not valid.");
            return "signup";
        }
    }


}
