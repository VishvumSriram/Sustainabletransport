package com.springplanner.travel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springplanner.travel.entity.User;

public interface UserRepository extends JpaRepository<User, Long>{
    User findByEmailId(String emailId);

    User findByUsername(String username);
}